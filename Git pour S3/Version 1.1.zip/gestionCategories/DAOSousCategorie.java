/*
 * DAOSousCategorie.java 		10/12/2020
 * Data Access Object pour la classe SousCategorie
 */
package gestionCategories;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * Data Access Object pour la classe SousCategorie
 * Classe qui va permettre de r�cup�rer des instances
 * SousCategorie en base de donn�e
 * @author Maxime Alliot
 *
 */
public class DAOSousCategorie {

	// Informations pour la connection � phpMyAdmin
	private static String login = "root";
	private static String passwd = "root";
	private static Connection cn =null;
	private static Statement st=null;
	
	/**
	 * M�thode qui permet de r�cup�rer toutes les sous cat�gories en base
	 * @return une ArrayList avec toutes les sous-cat�gories cr��es dans la base
	 */
	public static ArrayList<SousCategorie> getSousCategories() {
		ArrayList<SousCategorie> sousCategories = new ArrayList<>();
		
    	// R�cup�ration des donn�es en Base de donn�e
    	String sql = "SELECT nom FROM souscategorie";
		String url = "jdbc:mysql://localhost/quizztestconnaissances?serverTimezone=UTC";
		
		try {
			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);
			// Etape 3 : Cr�ation d'un statement
			st = cn.createStatement();

			// Etape 4 : Execution de la requ�te
			ResultSet res = st.executeQuery(sql);

			while(res.next()) {
				sousCategories.add(new SousCategorie(new Categorie(),res.getString("nom")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// Etape 5 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return sousCategories;
	}
	
	/**
	 * M�thode qui permet de r�cup�rer toutes les sous cat�gories en base
	 * en fonction d'une cat�gorie pass�e en param�tre
	 * @return une ArrayList avec toutes les sous-cat�gories cr��es dans la base+
	 * @param categorie Nom de la cat�gorie qui poss�de des sous cat�gories
	 */
	public static ArrayList<SousCategorie> getSousCategories(String categorie) {
		ArrayList<SousCategorie> sousCategories = new ArrayList<>();
		
    	// R�cup�ration des donn�es en Base de donn�e
    	String sql = "SELECT nom FROM souscategorie WHERE idSurCategorie ='"+DAOCategorie.getId(categorie)+"'";
		String url = "jdbc:mysql://localhost/quizztestconnaissances?serverTimezone=UTC";
		
		try {
			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);
			// Etape 3 : Cr�ation d'un statement
			st = cn.createStatement();

			// Etape 4 : Execution de la requ�te
			ResultSet res = st.executeQuery(sql);

			while(res.next()) {
				sousCategories.add(new SousCategorie(new Categorie(),res.getString("nom")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// Etape 5 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return sousCategories;
	}
	
	/**
	 * M�thode qui supprime une sous-cat�gorie en base
	 * @param nom Nom de la sous-cat�gorie � supprimer
	 */
	public static void supprSousCategorie(String nom) {
		// Modification des donn�es en Base de donn�e avec cette requ�te SQL
		String sql = "DELETE FROM souscategorie WHERE nom = '" + nom +"'";
		String sqlVerifDefaut ="SELECT defaut FROM souscategorie WHERE nom = '" + nom +"'";
		
		String url = "jdbc:mysql://localhost/quizztestconnaissances?serverTimezone=UTC";
		
		try {
			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);
			// Etape 3 : Cr�ation d'un statement
			st = cn.createStatement();
			
			// Etape 4 : Execution de la requ�te
			ResultSet res = st.executeQuery(sqlVerifDefaut);
			res.next();
			if (res.getInt(1) == 1) {
				System.out.println("La sous-cat�gorie par d�faut G�n�ral ne peut pas �tre supprim�e");
			} else {
				st.executeUpdate(sql);
				System.out.println("Suppression effectu�e !");
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException f) {
			f.printStackTrace();
		} finally {
			try {
				// Etape 5 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * M�thode qui va cr�er la table par d�faut dans la base de donn�e
	 */
	public static void creerTableDefaut() {
		boolean tableExiste = false;
		// Infos acc�s BD
		String url = "jdbc:mysql://localhost/quizztestconnaissances?serverTimezone=UTC";
		
		try {
			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);
			// Etape 3 : Cr�ation d'un statement
			st = cn.createStatement();
			
			// V�rification que la table des sous-cat�gories existe
			ResultSet resultSet = cn.getMetaData().getTables(null, null, "souscategorie", new String[] {"TABLE"});
			if (resultSet.next()) {
				tableExiste = true;
			}
			if (!tableExiste) {
				// Requ�te sql  pour cr�er la table souscat�gorie de l'application en localhost
				String sql = "CREATE TABLE souscategorie ( nom VARCHAR(255), defaut NUMERIC(10), lienphoto VARCHAR(255), idSurCategorie VARCHAR(255), id VARCHAR(255) PRIMARY KEY, CONSTRAINT fk_idSurCat FOREIGN KEY (idSurCategorie) REFERENCES categorie(id))";
				// Etape 4 : Execution de la requ�te
				st.executeUpdate(sql);
				System.out.println("Cr�ation de la table sous-cat�gorie");
				
				// Requ�te sql pour initialiser les sous-cat�gories avec g�n�ral
				sql = "INSERT INTO souscategorie (nom, defaut, lienphoto, idSurCategorie, id) VALUES ('G�n�ral', '1', 'null', '0', '0') ";
				st.executeUpdate(sql);
				System.out.println("Initialisation de la table avec la sous-cat�gorie 'g�n�ral'");
				
			} else {
				System.out.println("Table des sous-cat�gories d�j� existante");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// Etape 5 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * M�thode qui va cr�er une sous-cat�gorie et la mettre dans la base
	 * @param nom nom de la sous-cat�gorie
	 * @param lienPhoto lien vers la photo de la sous-cat�gorie (facultatif)
	 * @param surCategorie nom de la cat�gorie qui contient la nouvelle sous-cat�gorie
	 */
	public static void creerEnBase(String nom, String lienPhoto, String surCategorie) {
		// Infos acc�s BD
		String url = "jdbc:mysql://localhost/quizztestconnaissances?serverTimezone=UTC";
		
		try {
			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);
			// Etape 3 : Cr�ation d'un statement
			st = cn.createStatement();
			
			// Requ�te sql pour initialiser les sous-cat�gories 
			String sql = "INSERT INTO souscategorie (nom, defaut, lienphoto, idSurCategorie, id) VALUES ('" 
						+ nom + "', '0','" + lienPhoto + "','" + DAOCategorie.getId(surCategorie) + "','"+ getNextPrimaryKey() +"') ";
			st.executeUpdate(sql);
			System.out.println("Sous-cat�gorie " + nom + " correctement cr�e");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// Etape 5 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * R�cup�re la prochaine cl� primaire pour cr�er la suivante
	 * @return La derni�re cl� primaire +1
	 */
	public static int getNextPrimaryKey() {
		// Infos acc�s BD
		String url = "jdbc:mysql://localhost/quizztestconnaissances?serverTimezone=UTC";
		int resultat=0;
		Connection connect=null;
		Statement state=null;
		try {
			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Etape 2 : r�cup�ration de la connexion
			connect = DriverManager.getConnection(url, login, passwd);
			// Etape 3 : Cr�ation d'un statement
			state = connect.createStatement();
			
			// Requ�te sql pour initialiser les sous-cat�gories 
			String sql = "SELECT MAX(id) FROM souscategorie";
			ResultSet res = state.executeQuery(sql);
			res.next();
			resultat = res.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// Etape 5 : lib�rer ressources de la m�moire.
				connect.close();
				state.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultat+1;
	}
	
	/**
	 * Modifie le nom d'une sous-cat�gorie
	 * @param sousCategorie sous-cat�gorie � modifier
	 * @param newName nouveau nom
	 */
	public static void modifierNom(String sousCategorie, String newName) {
		// Modification des donn�es en Base de donn�e avec cette requ�te SQL
    	String sql = "UPDATE souscategorie SET nom = '" + newName +"', lienphoto = '' WHERE nom = '" 
    	                                                + sousCategorie+"'";
		
		// Infos acc�s BD
		String login = "root";
		String passwd = "root";
		Connection cn =null;
		Statement st=null;
		String url = "jdbc:mysql://localhost/quizztestconnaissances?serverTimezone=UTC";
		
		try {
			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);
			// Etape 3 : Cr�ation d'un statement
			st = cn.createStatement();
			
			// Etape 4 : Execution de la requ�te
			st.executeUpdate(sql);
			System.out.println("Modification effectu�e !");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// Etape 5 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
